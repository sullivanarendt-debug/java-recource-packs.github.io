#version 330

/*
 * Pure Bright - Resource Pack
 * Author: kotorito
 * License: MIT
 *
 * Minecraft Java Edition 26.2 compatibility update.
 * Overrides the lightmap shader to output maximum brightness
 * at all times, regardless of in-game lighting conditions.
 */

in vec2 texCoord;
out vec4 fragColor;

const float BRIGHTNESS = 1.0;

void main() {
    fragColor = vec4(BRIGHTNESS, BRIGHTNESS, BRIGHTNESS, 1.0);
}
